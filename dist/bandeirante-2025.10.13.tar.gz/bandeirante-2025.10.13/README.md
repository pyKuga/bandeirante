# bandeirante
General library for processing B3 financial series data (brazilian stock markets)

in development
